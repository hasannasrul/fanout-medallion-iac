

import json
import boto3

def handler(event, context):
    """
    event -> SQS => Lambda event:
    {
      "Records": [
        {
          "messageId": "...",
          "body": "<SNS JSON as string>",
          ...
        }
      ]
    }
    """
    print("SQS event:", event)

    for rec in event.get("Records", []):
        body = rec.get("body")
        try:
            sns_message = json.loads(body)
        except Exception:
            # Sometimes messages are direct; handle gracefully
            sns_message = None

        # If body is an SNS envelope, the original payload is in "Message"
        if sns_message and "Message" in sns_message:
            try:
                original = json.loads(sns_message["Message"])
            except Exception:
                original = sns_message["Message"]
        else:
            # If not SNS envelope, try parse body as JSON (direct SQS send)
            try:
                original = json.loads(body)
            except Exception:
                original = body

        print("Original payload:", original)

        # Example: handle S3 event --> extract bucket/key
        if isinstance(original, dict) and "Records" in original:
            for s3rec in original["Records"]:
                s3info = s3rec.get("s3", {})
                bucket = s3info.get("bucket", {}).get("name")
                key = s3info.get("object", {}).get("key")
                print(f"Bucket: {bucket}, Key: {key}")
                # TODO: process object, call other services, etc.

    return {"status": "ok"}
